require 'test_helper'

class ArchiveDecoratorTest < Draper::TestCase
end
