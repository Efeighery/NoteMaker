class Archive < ApplicationRecord
    has_rich_text :note_space
end
