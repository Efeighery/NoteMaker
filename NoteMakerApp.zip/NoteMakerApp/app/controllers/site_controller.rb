class SiteController < ApplicationController
  def home
  end
end
